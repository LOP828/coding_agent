# Coding Agent M0.2：修订后的契约与追溯实验包

本版修复 M0.1 的场景 04 错配，以及审批绑定、报告汇总、有效测试数、需求状态与结构覆盖缺口。**这是规格包及其本地自检，不是已经完成的 Coding Agent 或生产可信验证器。**

保留三个 Schema；PropertySpec 仍内嵌 AtomicTask，不增加第六个核心 AI 产物。M0 不接模型、不做沙箱、不采集真实 Git diff、不开发调度器。`checks/` 是小型规格参考实现及审计测试，供 Codex 核对规则，不是新的生产子系统。

## 1. 四个样本现在测什么

| 场景 | 任务/契约 | 实际用于该任务的验收测试 | 按任务的机器 gate | 独立原文基准判断 |
|---|---|---|---|---|
| 01 正确实现 | 正确，模拟 APPROVED | 正确测试：2 通过 | PASS | 符合本实验原文 |
| 02 直接违反原始需求 | 正确，模拟 APPROVED | 正确测试：1 通过、1 失败 | HARD_FAIL / EXECUTION_FAIL | 不符合 |
| 03 越权修改 | 正确，模拟 APPROVED | 行为测试：2 通过 | HARD_FAIL / EXECUTION_FAIL，由任务级范围规则阻断 | 行为正确不等于任务合规 |
| 04 完美实现错误契约 | 错误，但模拟误批准为 APPROVED | **错误测试：2 通过** | **PASS** | **原文测试 1 通过、1 失败，评测标签为 False PASS** |

表内测试数字在附带 Linux 自检中实际执行；范围 gate 的 changed_paths 仍是合成证据，不是生产 Git 审查。详细结果和退出码见 `audit_evidence/validation_summary.json`。

### 场景 04 的关键分离

原文保持不变：

> 如果配置缺少 provider 字段，必须抛出 MissingProviderError；不能使用默认 provider，也不能静默通过。

场景 04 的错误 Property 仍要求“缺少 provider 时填入 local”，代码也这样实现。其任务卡引用：

`tests_wrong_contract/test_provider_wrong_contract.py::test_missing_provider_defaults_to_local`

不再引用要求抛出异常的正确测试。错误契约和错误测试均有模拟批准及内容绑定，因此所有已声明机器检查确实可以通过。

`tests_reference/test_provider_requirement.py` 在场景 04 中是**评测者独立保留的原文 oracle（判断基准）**，不属于该任务已经批准的验收集合。自检在任务 gate 计算结束后另行运行它，以揭示 False PASS；不得把它偷偷注入当前任务 gate，再声称 M0 识别了语义漂移。

`FALSE_PASS_EXPECTED_KNOWN_GAP` 只是评测标签，不是运行时 gate 的新状态。运行时仍只有 PASS / HARD_FAIL / BLOCKED。

**仅增加 M1 隔离和冻结测试注入，这个错误契约仍可通过。** 后续独立语义审查的目标是在执行前识别冲突并 BLOCKED / TASK_SPEC_FAIL；本版未实现、未测得该能力，不能承诺接入 AI 后必然识别。将来做语义模型评测时，必须去除场景名、wrong 路径、代码注释和预期答案等泄题信息；本包不是盲测集。

### PENDING 不再冒充场景 04

PENDING / REJECTED 是独立的准入负例：在执行前拒绝，不调用 Executor，不签发执行后 VerificationReport。它只测试准入状态机边界，不测试语义理解。此规则由 `checks/test_spec_regressions.py` 单独验证。

## 2. 原始需求、状态和结构覆盖

源文件：`fixtures/source_requirements.json`。它是**合成实验原文**，不得冒称真实用户已经确认。

原文 `sha256_utf8`：对 JSON 解码后的 `raw_text` 字符串直接编码为 UTF-8 计算 SHA-256，不 trim、不改换行、不做 Unicode 归一化。原文有变更必须走新版本及重新批准，不得原地修哈希掩盖改动。本次 R-001 原文和其哈希未改变；旧压缩包也未覆盖。

正式模式中，所有任务引用的原文都必须满足 `status=FROZEN`、`source_kind=USER_MESSAGE`、`confirmation=USER_CONFIRMED`。`DRAFT`、`SUPERSEDED` 和未确认的原文不得准入。`PENDING` 在本 Schema 中是 confirmation 值，不是 status 值。

只有显式 `fixture_mode=True` 才可接受 `SYNTHETIC_FIXTURE + NOT_APPLICABLE_FIXTURE + FROZEN`。不能为了让实验通过而给合成原文贴 USER_CONFIRMED 标签。

结构预检同时要求：

- ID 唯一且可解析；每个 Property 的 requirement_refs 都属于该 AtomicTask 的 requirement_refs。
- 每条任务声明的需求，至少被一个 Property 关联。不得用任务级 DIFF 检查冒充需求覆盖。
- EXPLICIT、DERIVED 必须有来源，UNSOURCED 不得准入；有 ID 只证明结构关系，不证明语义覆盖或忠实度。

## 3. DERIVED 与范围授权

DERIVED 必须有非空推导理由，只能作为局部细化。`NEW_MODULE`、`NEW_DEPENDENCY`、`PUBLIC_INTERFACE_CHANGE`、`OUTSIDE_SCOPE` 对任何来源类型都需要额外授权。

授权不是把 `scope_expansion_authorized` 写成 true：还要给出 `scope_authorization_ref`，并匹配控制层持有的、绑定 task_id / property_id / scope_impact 的已批准记录。本包没有任何范围扩张授权。

M0 只能校验**声明的** scope_impact 与授权关系，不能自动发现 AI 把真实扩张错标成 LOCAL_REFINEMENT。误分类仍是语义审查和人工抽查要处理的缺口；不能靠添加理由绕过风险授权。抽查优先覆盖 DERIVED，但 M0 不实现抽样系统。

## 4. 审批绑定：内容哈希不是审批权限

APPROVED 记录必须含 `approval_ref` 和 `approved_payload_sha256`。批准摘要绑定：

- AtomicTask 中除 acceptance_review 以外的所有字段，包括 Property 文本、来源、检查方法/引用/必需标记、允许/保护路径、范围声明与授权引用。
- task_checks、验收测试清单及清单中的内容哈希。
- 所引用的原始需求完整记录，按需求 ID 排序，包括原文、来源、确认状态及原文哈希。

确定性序列化固定为：

```python
json.dumps(payload, ensure_ascii=False, sort_keys=True,
           separators=(",", ":"), allow_nan=False).encode("utf-8")
```

这是本版受限 JSON 字段集合的序列化约定，不声称通用跨语言规范化标准。摘要不包括 acceptance_review，避免自身包含自身；审批状态和批准权由独立记录核对，不靠 hash 自证。

验收测试使用 `sha256_utf8_lf`：UTF-8 解码、拒绝 BOM、CRLF/CR 统一为 LF 后哈希。它绑定逻辑文本内容，避免 `core.autocrlf=true` 的换行转换被误报为测试变化；与原始需求的逐字符串字节哈希是两个不同规则。测试路径相同但内容变化也会阻断。

`fixtures/trusted_review_records.json` 只是**模拟控制层可信记录**，不是签名或安全存储。参考预检会核对此独立记录，因此“修改任务并自行重算批准 hash”仍不能通过。生产记录必须放在 Executor 无写权限的控制侧；本包没有实现该权限边界，不能把这里的 JSON 文件当成防攻击的实现。

## 5. 检查结果、报告与 gate

检查状态仍为 PASS / FAIL / NOT_RUN / UNVERIFIABLE。

任务内的每条检查由 `(property_id, method, reference)` 标识；任务级检查使用 `property_id=null`。`DIFF_ALLOWLIST` 已从 P-001 移到 `task_checks`，不在多条行为 Property 下重复出现。

UNIT_TEST / PROPERTY_TEST 的 PASS 必须有 `test_count >= 1`。本字段表示实际执行的测试/样例数量，不是收集数量；全 skip、不运行、无匹配项不能按 PASS+正数伪报。Schema 只能验证填值和类型，数字真实性由未来可信 Runner 从执行证据产生。

报告要匹配 task_id、控制层指定的代码 revision 和已批准内容摘要。报告不能自己降低 required 标记、换检查引用、重复同一行凑覆盖，或用未声明检查冒充必需检查。

**gate 的权威来源是纯函数，不是 report.gate：**

```text
aggregate_gate(task, results, changed_paths) -> computed_gate
```

函数没有 gate 输入。`VerificationReport.gate` 仅是待核对声明；status/route 与重算结果不一致时，报告不可用于放行，同时保留实际重算结果。不要读取报告的 reason 猜测结论，也不要按样本编号写特殊判定。

规则固定为：已证实越权或必需检查 FAIL → HARD_FAIL；未执行/遗漏/无法验证的必需检查 → BLOCKED；全部必需检查有有效 PASS 才可机器 PASS。Schema 错误、报告身份不匹配、未知/重复检查、审批失配等均拒绝放行，不得转成 PASS。可选检查的缺失不补成 PASS；其结果不代替必需检查。

`changed_paths` 的集合仍是 M0 合成可信输入，DIFF 结果会由范围规则重算。M1 才负责从受控工作区独立获取真实变更、运行测试并产出可信证据；本包没有实现这个来源保证。

## 6. 路径约定与冲突优先级

M0 不使用宿主系统 glob、`Path.match()` 或 shell 展开。只支持两种形式：精确相对 POSIX 文件路径；以及以 `目录/**` 结尾的子树规则，例如 `tests_reference/**`。

`tests_reference/**` 匹配该目录直接及任意深度子文件，不匹配 `tests_reference_backup/...`。策略按字符大小写敏感比较，Windows/Linux 都使用同一纯函数。不接受其他通配符、绝对路径、驱动器冒号、反斜线、空段、`.`、`..` 或控制字符。输入应来自可信 Git 路径表示；记录本地 Path 时用 `as_posix()`。

**protected_paths 优先于 allowed_change_paths**。两者重叠时拒绝修改，不得因白名单更具体而覆盖保护规则。

这只是可重复的逻辑路径检查，不是 Windows/Linux 文件系统安全边界。符号链接、大小写别名、挂载点、文件系统权限等需 M1 的受控执行另行处理，不能把字符串匹配当成沙箱。

## 7. 文件布局

```text
schemas/                 3 个版本化 JSON Schema
fixtures/                1 份原文、4 份任务卡、4 份期望报告
                         + 模拟控制侧审批/范围授权记录
example_code/            四份候选代码；03 额外修改 project_config.py
tests_reference/        正确的原文基准；01–03 验收使用，04 评测侧使用
tests_wrong_contract/   04 的错误契约测试
checks/                  规格参考函数、70 项规则回归、本地示例自检
CODEX_TASK.md            修订后的开发交接提示词
CHANGELOG.md             逐项修复与能力边界
VALIDATION.md            本次实跑摘要
audit_evidence/         JSON、JUnit XML 与原始输出日志
```

## 8. 复现与交接

使用 Python 3.11+ 和所用项目允许的依赖环境。`requirements-selfcheck.txt` 记录此次审计安装的 pytest/jsonschema 版本，不宣称最新，也不要求覆盖已有项目锁文件。

在解压后的本目录执行：

```powershell
python -m pytest
python checks/run_selfcheck.py
```

第一条仅执行本包规则回归。第二条还会在临时目录实际运行四份**已知、可信的演示代码**及独立 oracle，输出日志。临时目录不是安全沙箱，不可拿此脚本运行未知不可信代码。故意错误样本的 pytest 子进程失败码会完整保留；自检成功只表示实际表现匹配基准，不表示所有候选实现正确。

包内 `pytest.ini` 只用于避免将演示性失败测试误当本包默认单测。**不得覆盖目标仓库现有 pytest 配置以缩小全量测试范围。** 新增 M0 功能测试须进入目标仓库正常主线，不得加 `legacy_frozen` 标记。

本轮实际完成 Linux 自检；未运行 Windows 原生 CP936 验收。CRLF 单测通过不等于 Windows 通过。M0 不包含真实业务仓库，self_media_agent 的 CORE 两项目验收也未执行；交接要求见 CODEX_TASK.md。
