# M0.2 实际验证记录

验证日期：2026-10-18。结果来自本地实际执行，不是根据期望报告抄写。

## 环境与总体边界

| 项目 | 实际结果 |
|---|---|
| 操作系统 | Linux |
| Python | 3.13.5 |
| pytest / jsonschema | 9.0.2 / 4.26.0 |
| 子进程 PYTHONUTF8 | 未设置 |
| 3 份 Schema 与 9 份核心样本 | 均通过结构校验 |
| 审批摘要、模拟控制侧批准、测试内容清单 | 四个场景均匹配 |
| 规则回归 | **70 passed / 0 failed / 0 errors / 0 skipped** |
| Windows 原生中文 CP936 | **NOT_RUN**，未声称通过 |
| 真实 Git diff、权限沙箱、生产批准存储 | **未实现、未验证** |
| 模型语义审查 | **未接入、未验证** |

另外做了 CRLF 文本清单哈希一致性的单元测试；该测试不能替代 Windows 原生运行。

## 先复现旧版问题

旧版 04 用正确原文测试运行，真实结果为 **1 passed / 1 failed / 0 errors / 0 skipped，退出码 1**。失败测试为 `test_missing_provider_raises`，确实与旧版期望报告中的 PASS 不一致。

原始日志见 `audit_evidence/original_v0_1_case04.log`，四个旧样本的统计见 `original_v0_1_summary.json`。本轮未覆盖原压缩包。

## 修订后的实际代码测试

| 场景 / 测试来源 | passed | failed | errors | skipped | pytest 退出码 |
|---|---:|---:|---:|---:|---:|
| 01 / 声明的正确验收测试 | 2 | 0 | 0 | 0 | 0 |
| 02 / 声明的正确验收测试 | 1 | 1 | 0 | 0 | 1 |
| 03 / 声明的正确验收测试 | 2 | 0 | 0 | 0 | 0 |
| 04 / 声明的错误契约测试 | **2** | **0** | 0 | 0 | **0** |
| 04 / 独立原文 oracle | **1** | **1** | 0 | 0 | **1** |

这些子进程失败是故障注入样本的真实表现，未被抹掉或改成测试通过。自检 harness 的 `MATCHED_EXPECTATIONS` 只表示这些差异符合实验定义。

任务级 gate 使用合成报告和合成 changed_paths，经纯函数重算为 01 PASS、02 HARD_FAIL、03 HARD_FAIL、04 PASS。03 的规则拒绝不是生产 Git/沙箱验证。04 的原文 oracle 结果只进入评测输出，不进入任务 gate；因此真实暴露的是 **已知 False PASS**，不是机器已经识别了语义扭曲。

## 数据与文件完整性

R-001 原文未变，精确 UTF-8 SHA-256 为：

`dbc51838e791950a5f8192dba714f7e9baa7eab0fbfd2bf225d2bd7595176ffe`

保留的原始 M0.1 压缩包 SHA-256 为：

`82ad150d464f810758bb6f979374ca0ce8af9d71f8a53d0aaeaa3bf2148ecd56`

m0.2 修改了任务/检查定义和审批内容，所以使用新的版本号与新批准摘要，不沿用旧批准。所有可信审批记录均明确是合成夹具，不是用户真实审批。

## 复现

在本包根目录执行：

```powershell
python -m pytest
python checks/run_selfcheck.py
```

详细机器记录为 `audit_evidence/validation_summary.json`；每次 pytest 子运行均有同目录 JUnit XML 和原始日志。随包日志来自本次 Linux 环境。目标仓库的真实 M0 实现、Windows 验收以及业务仓库 CORE 测试必须另行实际运行，不能用本包数字替代。
