class MissingProviderError(ValueError):
    pass


def validate_config(config):
    if "provider" not in config:
        raise MissingProviderError("Configuration is missing required 'provider'")
    return config
