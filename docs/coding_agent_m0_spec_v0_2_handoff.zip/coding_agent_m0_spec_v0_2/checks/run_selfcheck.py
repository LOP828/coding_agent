"""Run honest M0 fixture checks plus local executions of trusted toy examples.

Fresh temporary directories are cleanup/isolation of examples, NOT a security
sandbox. This script is not a production Verification Runner.
"""
from __future__ import annotations

import argparse
import importlib.metadata
import json
import os
import platform
import shutil
import subprocess
import sys
import tempfile
import xml.etree.ElementTree as ET
from pathlib import Path
from typing import Any

from spec_reference import (
    aggregate_gate, approval_payload_sha256, read_json, validate_admission,
    validate_report, validate_schema,
)

ROOT = Path(__file__).resolve().parents[1]
CASES = ["01_correct", "02_requirement_violation", "03_scope_violation", "04_wrong_acceptance"]


def write_json(path: Path, data: dict[str, Any]) -> None:
    path.write_text(json.dumps(data, ensure_ascii=False, indent=2) + "\n", encoding="utf-8", newline="\n")


def junit_counts(path: Path) -> dict[str, int]:
    tree = ET.parse(path)
    cases = tree.findall(".//testcase")
    failed = sum(c.find("failure") is not None for c in cases)
    errors = sum(c.find("error") is not None for c in cases)
    skipped = sum(c.find("skipped") is not None for c in cases)
    return {"total": len(cases), "passed": len(cases) - failed - errors - skipped,
            "failed": failed, "errors": errors, "skipped": skipped}


def execute_pytest(cwd: Path, nodes: list[str], label: str, output: Path) -> dict[str, Any]:
    xml = output / f"{label}.xml"
    env = os.environ.copy()
    env.pop("PYTHONUTF8", None)
    env.pop("PYTEST_ADDOPTS", None)
    env["PYTEST_DISABLE_PLUGIN_AUTOLOAD"] = "1"
    env["PYTHONPATH"] = str(cwd)
    command = [sys.executable, "-m", "pytest", "-q", "--noconftest", *nodes, "--junitxml", str(xml)]
    completed = subprocess.run(command, cwd=cwd, env=env, capture_output=True, timeout=30, check=False)
    log = completed.stdout.decode("utf-8", errors="replace") + "\n" + completed.stderr.decode("utf-8", errors="replace")
    (output / f"{label}.log").write_text(log, encoding="utf-8", newline="\n")
    return {"exit_code": completed.returncode, **junit_counts(xml),
            "junit_xml": xml.name, "log": f"{label}.log"}


def execute_candidate(case: str, references: list[str], label: str, output: Path) -> dict[str, Any]:
    with tempfile.TemporaryDirectory(prefix="m0-candidate-") as tmp:
        work = Path(tmp)
        for file in (ROOT / "example_code" / case).glob("*.py"):
            shutil.copyfile(file, work / file.name)
        for name in sorted({ref.split("::", 1)[0] for ref in references}):
            target = work / name
            target.parent.mkdir(parents=True, exist_ok=True)
            shutil.copyfile(ROOT / name, target)
        return execute_pytest(work, references, label, output)


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", type=Path, default=ROOT / "audit_evidence")
    args = parser.parse_args()
    out = args.output.resolve()
    out.mkdir(parents=True, exist_ok=True)
    source = read_json(ROOT / "fixtures/source_requirements.json")
    trusted = read_json(ROOT / "fixtures/trusted_review_records.json")
    validate_schema(ROOT, "source_requirements", source)
    checked_documents = 1
    admissions = []
    for case in CASES:
        task = read_json(ROOT / "fixtures" / case / "atomic_task.json")
        report = read_json(ROOT / "fixtures" / case / "verification_report_expected.json")
        validate_admission(task, source, trusted, ROOT, fixture_mode=True)
        gate = validate_report(task, report, ROOT, expected_revision=f"synthetic-{case[:2]}")
        checked_documents += 2
        admissions.append({"case": case, "admission": "READY", "computed_gate": gate,
                           "approval_payload_sha256": approval_payload_sha256(task, source),
                           "evidence_kind": "SYNTHETIC_REPORT_AND_SYNTHETIC_CHANGED_PATHS"})
    regressions = execute_pytest(ROOT, ["checks/test_spec_regressions.py"], "policy_regressions", out)
    actual_runs = []
    all_match = regressions["exit_code"] == 0 and regressions["total"] > 0
    for case in CASES:
        task = read_json(ROOT / "fixtures" / case / "atomic_task.json")
        references = [c["reference"] for prop in task["properties"] for c in prop["checks"] if c["method"] == "UNIT_TEST"]
        result = execute_candidate(case, references, f"{case}_declared_tests", out)
        expected_failed = 1 if case.startswith("02") else 0
        match = (result["total"] == 2 and result["failed"] == expected_failed
                 and result["errors"] == 0 and result["skipped"] == 0
                 and result["exit_code"] == (1 if expected_failed else 0))
        actual_runs.append({"case": case, "test_source": "TASK_DECLARED_ACCEPTANCE", **result,
                            "matched_expected_behavior": match})
        all_match = all_match and match
    # An evaluator-only baseline, deliberately never fed into aggregate_gate.
    oracle_refs = [
        "tests_reference/test_provider_requirement.py::test_missing_provider_raises",
        "tests_reference/test_provider_requirement.py::test_present_provider_unchanged",
    ]
    oracle = execute_candidate(CASES[3], oracle_refs, "04_independent_source_oracle", out)
    oracle_match = (oracle["exit_code"] == 1 and oracle["total"] == 2 and oracle["passed"] == 1
                    and oracle["failed"] == 1 and oracle["errors"] == 0 and oracle["skipped"] == 0)
    all_match = all_match and oracle_match
    summary = {
        "package_version": "m0.2",
        "environment": {
            "system": platform.system(), "python": platform.python_version(),
            "pytest": importlib.metadata.version("pytest"), "jsonschema": importlib.metadata.version("jsonschema"),
            "child_pythonutf8": "UNSET", "pytest_plugin_autoload": "DISABLED",
            "windows_native_validation": "NOT_RUN" if platform.system() != "Windows" else "SEE_ACTUAL_ENVIRONMENT",
        },
        "schema_validation": {"schemas_checked": 3, "core_fixture_documents_checked": checked_documents, "result": "PASS"},
        "admission_and_synthetic_gate_checks": admissions,
        "policy_regressions": regressions,
        "actual_candidate_test_runs": actual_runs,
        "independent_evaluator_only_oracle_04": {**oracle, "matched_expected_behavior": oracle_match},
        "known_gap_04": {
            "computed_task_gate": "PASS", "source_oracle_result": "FAIL",
            "evaluation_label": "FALSE_PASS_EXPECTED_KNOWN_GAP",
            "runtime_gate_has_false_pass_status": False,
            "m1_isolation_alone_does_not_fix_wrong_acceptance": True,
            "m2_semantic_detection": "NOT_IMPLEMENTED_NOT_CLAIMED",
        },
        "harness_verdict": "MATCHED_EXPECTATIONS" if all_match else "MISMATCH",
        "limits": [
            "Expected report rows and changed_paths are synthetic, not a trusted Git audit.",
            "Candidate tests ran locally, but temporary directories are not a security sandbox.",
            "Known wrong examples intentionally produce failed pytest cases; raw outcomes are retained.",
            "This checks the specification package, not production safety, security, or reliability.",
        ],
    }
    write_json(out / "validation_summary.json", summary)
    print(json.dumps({"harness_verdict": summary["harness_verdict"],
                      "policy_regressions": regressions,
                      "candidate_runs": actual_runs,
                      "case04_source_oracle": oracle}, ensure_ascii=True, indent=2))
    return 0 if all_match else 1


if __name__ == "__main__":
    raise SystemExit(main())
